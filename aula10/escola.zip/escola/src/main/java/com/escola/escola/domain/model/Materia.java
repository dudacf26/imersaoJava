package com.escola.escola.domain.model;

import javax.persistence.*;

@Entity
@Table(name = "materia")
public class Materia extends BaseEntity{

    @Column(name = "nome")
    private String nome;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }
}
