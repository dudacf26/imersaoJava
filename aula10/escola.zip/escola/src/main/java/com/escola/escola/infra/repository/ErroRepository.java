package com.escola.escola.infra.repository;

import com.escola.escola.domain.model.Erro;
import org.springframework.stereotype.Repository;

@Repository
public interface ErroRepository extends BaseRepository<Erro> {
}
