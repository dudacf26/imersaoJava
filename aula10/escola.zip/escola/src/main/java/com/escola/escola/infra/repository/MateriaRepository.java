package com.escola.escola.infra.repository;

import com.escola.escola.domain.model.Materia;

public interface MateriaRepository extends BaseRepository<Materia> {
}
