package com.escola.escola.infra.repository;

import com.escola.escola.domain.model.Estudante;
import org.springframework.stereotype.Repository;

@Repository
public interface EstudanteRepository extends BaseRepository<Estudante> {
}
